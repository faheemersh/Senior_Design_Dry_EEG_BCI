function res = double(a);

res = double(a.data.data.x);