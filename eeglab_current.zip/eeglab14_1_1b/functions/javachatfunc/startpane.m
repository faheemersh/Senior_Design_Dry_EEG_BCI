import client.EEGLABChat;
import client.VisualToolbar;
import java.awt.*;
import javax.swing.*;

tb = VisualToolbar();
F = gcf;
tb.setPreferredSize(Dimension(0, 75));

javacomponent(tb,'South',F);

refresh(F);
