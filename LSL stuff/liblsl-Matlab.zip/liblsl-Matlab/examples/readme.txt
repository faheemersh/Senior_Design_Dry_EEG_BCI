To run these examples, you must have added the folder include/lsl_matlab to your MATLAB path (recursively).
You can do this either via the File/Path... menu or via the command addpath(genpath('your_path_to/liblsl-1.xx/include/lsl_matlab'))
Also, if you have rebuilt the library, make sure that liblsl-1.xx/include/lsl_matlab/bin contains a copy of the library files in the liblsl-1.xx/bin.