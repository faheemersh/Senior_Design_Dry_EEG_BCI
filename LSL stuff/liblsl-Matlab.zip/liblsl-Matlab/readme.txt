This is the MATLAB interface for liblsl. You need to add this directory to your MATLAB path recursively (File/Set Path...)
The bin/ directory needs to contain an up-to-date build of the library file for your MATLAB version (e.g. liblsl64.dll for 64-bit MATLAB on Windows). 
Once this taken care of, see the example files in the examples/ directory for how to use this interface in a MATLAB program.
