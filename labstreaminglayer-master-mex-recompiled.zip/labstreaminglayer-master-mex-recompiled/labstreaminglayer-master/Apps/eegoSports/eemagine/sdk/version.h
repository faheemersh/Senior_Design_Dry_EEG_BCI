#ifndef __eemagine_sdk_version_h__
#define __eemagine_sdk_version_h__

#define EEGO_SDK_VERSION_MAJOR 1
#define EEGO_SDK_VERSION_MINOR 3
#define EEGO_SDK_VERSION_MICRO 4
#define EEGO_SDK_VERSION       31165

#endif
