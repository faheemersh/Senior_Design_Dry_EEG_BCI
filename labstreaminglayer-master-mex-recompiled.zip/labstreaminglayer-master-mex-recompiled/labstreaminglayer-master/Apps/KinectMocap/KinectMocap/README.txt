This program connects to the first Kinect connected to your PC and streams the data into LSL.
You may have to install the Kinect Runtime in order to make use of this program from here: http://go.microsoft.com/fwlink/?LinkId=253187
If the link does not work, download the SDK from here http://www.microsoft.com/en-us/kinectforwindows/Develop/Developer-Downloads.aspx
