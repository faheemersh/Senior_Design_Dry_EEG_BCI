This Program was kindly provided by Brain Products GmBH (written by Norbert Hauser) with minor modifications.
To use this program, you need to own the BrainVision recorder, and enable Remote Data Access (RDA). This program connects to the BrainVision Recorder and links the signal to the lab streaming layer.
