These are two console programs that translate selected streams between LSL and MQTT (Message Queue Telemetry Transport).

The implementation uses Roger Light's mosquitto library (mosquitto.org).