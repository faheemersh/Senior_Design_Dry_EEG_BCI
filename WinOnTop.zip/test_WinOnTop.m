function  test_WinOnTop(  )
%TEST_WINONTOP is a simple test of WinOnTop function functionality
%

hf=figure();
WinOnTop(hf);

end

